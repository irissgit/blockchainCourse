let {bytecode, interface} = require('./01_compile')
let Web3 = require('web3')
let HDWalletProvider = require('truffle-hdwallet-provider')
let terms = 'letter debris ready dog window mountain front truth project bottom merit valley'
// let terms = 'draw drum hamster glide mystery seek venture twist gown primary drill lonely'
let ropstenNet = 'https://rinkeby.infura.io/v3/3ea7b84f02e34f36874d9e26a104b6e9'
// let ropstenNet = 'http://127.0.0.1:7545'
let provider = new HDWalletProvider(terms, ropstenNet)
let web3 = new Web3(provider)

let contract = new web3.eth.Contract(JSON.parse(interface))
let deploy = async () => {
    let accounts = await web3.eth.getAccounts()
    console.log('Attempting to deploy from account',accounts[0]);
    let instance = await contract.deploy({
        data: bytecode,
        arguments: [],
    }).send({
        from: accounts[0],
        gas: '3n000000',
    })
    console.log('address: ', instance.options.address)
}

deploy()