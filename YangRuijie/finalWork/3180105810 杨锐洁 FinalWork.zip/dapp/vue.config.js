module.exports = {
    devServer:{
        open:true,
        port:3000
    }
}