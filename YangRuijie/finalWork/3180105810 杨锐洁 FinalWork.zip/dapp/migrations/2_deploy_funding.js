const Funding = artifacts.require("funding");

module.exports = function (deployer) {
  deployer.deploy(Funding);
};
