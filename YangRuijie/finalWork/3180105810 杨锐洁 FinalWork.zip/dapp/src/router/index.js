import Vue from 'vue'
import Vuetab from 'vue-router'
import Home from '../views/Home.vue'
import All from '../views/Allproject.vue'
import Create from '../views/Create.vue'
import Use from '../views/Use.vue'
import Myc from '../views/MyCreate.vue'
import Myi from '../views/MyInvestment.vue'

Vue.use(Vuetab)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/allproject',
    name: 'All',
    component: All
  },
  {
    path: '/create',
    name: 'Create',
    component: Create
  },
  {
    path: '/ues',
    name: 'Use',
    component: Use
  },
  {
    path: '/mycreate',
    name: 'MyCreate',
    component: Myc
  },
  {
    path: '/myinvest',
    name: 'MyInvestment',
    component: Myi
  }
]

const router = new Vuetab({
  routes
})

export default router
