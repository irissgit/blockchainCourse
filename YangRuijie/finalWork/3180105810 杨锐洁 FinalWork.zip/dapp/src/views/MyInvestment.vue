<template>
  <el-table :data="my_funding" stripe height=tableHeight style="width: 100%">
    <el-table-column prop="name" label="项目名称" width="tableWideth">
    </el-table-column>
    <el-table-column prop="projectTarget" label="目标金额" width="tableWideth"></el-table-column>
    <el-table-column prop="already" label="已筹金额" width="tableWideth"></el-table-column>
    <el-table-column prop="projectInfo" label="项目简介" width="tableWideth"></el-table-column>
    <el-table-column prop="date" label="截止时间" width="tableWideth"></el-table-column>
     <el-table-column label="您的操作" width="tableWideth">
      <template slot-scope="scope">
        <el-button @click="ClickYES(scope.row)" type="bblue" size="fault">同意</el-button>
        <el-button @click="ClickNO(scope.row)" type="bblue" size="fault">不同意</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
  export default {
    data() {
      //初始值
      return {
        allFundings: [],
        my_funding:[],
        screenWidth: document.body.clientWidth,//屏幕宽度
        tableWideth: window.innerWidth - 300, //table宽度
        screenHeight: document.body.clientHeight,//屏幕高度
        tableHeight: window.innerHeight - 300 //table高度
      }
    },
        
    async mounted(){
      //窗口
      window.onresize = () => {
          this.screenWidth = document.body.clientWidth;
          this.tableWideth=this.screenWidth-300;
          this.screenHeight = document.body.clientHeight;
          this.tableHeight=this.screenHeight-300;
          };
      let accounts = await this.GLOBAL.web3.eth.getAccounts();
      this.account=accounts[0];
      console.log(this.account)

      this.allFundings=[];
      this.my_funding=[];
      let TotalFunds = await this.GLOBAL.contract.methods.TotalFunds().call();

      for(let i=0;i<TotalFunds;i++){
        let funding=await this.GLOBAL.contract.methods.Fundings(i).call();
        let date=new Date(funding.time*1000)
        let Fund={
          id:i,
          name:funding.name,
          projectTarget:funding.projectTarget,
          already:funding.already_sum,
          projectInfo:funding.projectInfo,
          date:date.toString(),
          status:funding.status,
          manager:funding.manager
        }
        this.allFundings.push(Fund);

        let funders= await this.GLOBAL.contract.methods.getInvestors(i).call();
        for(let j=0;j<funders.length;j++)
        {
          if(funders[j]==this.account)
          {
            this.my_funding.push(Fund)
            break;
          }
        }
      }
      console.log(this.my_funding)
    },
    methods:{
      async ClickYES(row)
      {
        try {
              await this.GLOBAL.contract.methods.ReqApprove(row.id,true).send({
                from: this.account,
              });
              alert("操作成功");
            } catch (e) {
              alert("操作失败");
            }
        location.reload();
      },
      async ClickNO(row)
      {
        try {
              await this.GLOBAL.contract.methods.ReqApprove(row.id,false).send({
                from: this.account,
              });
              alert("操作成功");
            } catch (e) {
              alert("操作失败");
            }
        location.reload();
      }
    }
  }
</script>

<style>
/* 查询按钮 */
.el-button--bblue {
  color: rgb(148, 197, 238);
  background-color: rgb(240, 248, 255);
  border-color: rgb(148, 197, 238);
}

.el-button--bblue:hover {
  color: rgb(240, 248, 255);
  background-color: rgb(148, 197, 238);
  border-color: rgb(148, 197, 238);
}
</style>