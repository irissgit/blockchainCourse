<template>
  <div class="home">
  <div>
    <h4>您的地址：</h4>
    <p>{{account}}</p>
  </div>
    <h4>众筹项目：</h4>
    <el-button type="bblue" icon="el-icon-plus" @click="add">所有项目</el-button>
    <h4>您的项目：</h4>
    <el-button type="bblue" icon="el-icon-plus" @click="mycreate">您发起的项目</el-button>
    <el-button type="bblue" icon="el-icon-plus" @click="myinvest">您投资的项目</el-button>
    <h4>操作：</h4>
    <el-button type="bblue" icon="el-icon-plus" @click="create">发起项目</el-button>
    <el-button type="bblue" icon="el-icon-plus" @click="ues">申请使用</el-button>
    
  </div>
</template>

<script>
export default {
  methods: {
    add () {
      this.$router.push({path: '/allproject'})
    },
    create(){
      this.$router.push({path: '/create'})
    },
    mycreate(){
      this.$router.push({path: '/mycreate'})
    },
    myinvest(){
      this.$router.push({path: '/myinvest'})
    },
    ues(){
      this.$router.push({path: '/use'})
    }
  },
  data() {
    return {
      account:""
    };
  },
  async mounted()
  {
    let accounts = await this.GLOBAL.web3.eth.getAccounts();
    this.account=accounts[0];
    console.log(this.account)
  }
};
</script>
  
<style>
/* 查询按钮 */
.el-button--bblue {
  color: rgb(148, 197, 238);
  background-color: rgb(240, 248, 255);
  border-color: rgb(148, 197, 238);
}

.el-button--bblue:hover {
  color: rgb(240, 248, 255);
  background-color: rgb(148, 197, 238);
  border-color: rgb(148, 197, 238);
}

</style>
