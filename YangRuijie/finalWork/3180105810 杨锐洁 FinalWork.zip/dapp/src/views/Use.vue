<template>
  <el-form ref="form" :model="form" label-width="80px">
    <el-form-item label="项目名称">
      <el-input v-model="form.name" placeholder="请输入项目名称"></el-input>
    </el-form-item>
    <el-form-item label="申请金额">
      <el-input v-model="form.usemoney" placeholder="请输入申请使用的金额"></el-input>
    </el-form-item>
    <el-form-item label="申请理由">
      <el-input v-model="form.UseInfo" placeholder="请输入申请理由（200字内）"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="bblue" @click="onSubmit()">确认</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: "{{name}}",
        usemoney: 0,
        UseInfo: "",
        date: "",
      },
    };
  },
  methods: {
    async onSubmit() {
      console.log("成功");
      let accounts = await this.GLOBAL.web3.eth.getAccounts();
      let account = accounts[0];
      try {
              await this.GLOBAL.contract.methods
                .GetRequest(
                  this.form.name,
                  this.form.usemoney,
                  account,
                );
              alert("申请成功，等待投票");
          }catch (e) {
            console.log(e)
            alert("操作失败");
          }
    },
  },
};
</script>

<style>
/* 查询按钮 */
.el-button--bblue {
  color: rgb(148, 197, 238);
  background-color: rgb(240, 248, 255);
  border-color: rgb(148, 197, 238);
}

.el-button--bblue:hover {
  color: rgb(240, 248, 255);
  background-color: rgb(148, 197, 238);
  border-color: rgb(148, 197, 238);
}
</style>