<template>
  <div id="dapp">
    <el-container direction="vertical">
      <el-header><nheader></nheader></el-header>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import Header from './components/Header'

export default {
  name: 'dapp',
  components: {
    'nheader':Header
  }
}
</script>

<style>
#dpp {
  width:80%;
  height:100%;
  margin:0 auto;
}
.el-main{
  min-height: calc(100vh - 140px)
}
  

</style>
