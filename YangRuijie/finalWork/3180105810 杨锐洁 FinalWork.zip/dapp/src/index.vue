<script>
import Web3 from "web3";
import Crowdfunding from "../build/contracts/funding.json";

window.ethereum.enable();
const web3 = new Web3(window.ethereum);
const contract = new web3.eth.Contract(
  Crowdfunding.abi,
  "0xe8139D9659AECEf3938a4dbA7f5dAc64a28c425d"
);

async function getAccount() {
    return (
      await web3.eth.getAccounts()
      )[0];
}

export default {
  web3,
  contract,
  getAccount,
};
</script>