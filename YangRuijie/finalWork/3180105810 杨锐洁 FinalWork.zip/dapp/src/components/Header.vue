<template>
  <el-menu :default-active="this.$route.path" class="el-menu-demo" mode="horizontal" @select="handleSelect">
    <el-container style="float: left">
      <el-menu-item index="0" @click="goTo('/')">众筹DAPP平台</el-menu-item>
    </el-container>
  </el-menu>
</template>

<script>
export default {
  data() {
    return {
      activeIndex: "1",
      activeIndex2: "1",
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
    goTo(path) {
      this.$router.replace(path);
    },
  },
};
</script>